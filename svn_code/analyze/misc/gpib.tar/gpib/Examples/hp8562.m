function [x, y] = hp8562( op, data )

%   function hp8562( op, data )
%
%   hp8562( 'open' )	-- open GPIB device
%   hp8562( 'close' )	-- close GPIB device
%   hp8562( 'center' ) 	-- get/set center frequency (Hz)
%   hp8562( 'span' )	-- get/set frequency span (Hz)
%   hp8562( 'rbw' )	-- get/set resolution BW (Hz)
%   hp8562( 'sweep' )	-- get/set sweep time (sec)
%   hp8562( 'ref' )	-- get/set reference level (dBm) 
%   hp8562( 'atten' )	-- get/set input attenuator (dB) 
%   hp8562( 'peaks' )	-- get n largest peaks 
%   hp8562( 'mark' )	-- get marker freq and amp 
%   hp8562( 'trace' )	-- get trace A data 
%   hp8562( 'plot' )	-- plot trace A data 
%   hp8562( '10mhz' )	-- select 10 MHz reference  'data' int/ext


global lcl_hp8562
ud = lcl_hp8562;
dev = 'dev7';

if strcmp( op, 'open' ),
    hp8562( 'close' );
	
    ud = gpib( 'find', dev );
    if ud < 0,
	error( ['Couldn''t find ' dev] );
    end
    gpib( 'clr', ud );
    gpib( 'wrt', ud, 'IP; AUNITS DBM; AUTOCPL' );   % units: dBm; auto couple
    lcl_hp8562 = ud;


elseif strcmp( op, 'center' ),			    % center freq
    if nargin<2,
	gpib( 'wrt', ud, 'CF?' );
	x = str2num( gpib( 'rd', ud ) );
    else
	gpib( 'wrt', ud, ['CF' sprintf('%.0f',data) 'HZ'] );
    end


elseif strcmp( op, 'span' ),			    % span
    if nargin<2,
	gpib( 'wrt', ud, 'SP?' );
	x = str2num( gpib( 'rd', ud ) );
    else
	gpib( 'wrt', ud, ['SP' sprintf('%.0f',data) 'HZ'] );
    end


elseif strcmp( op, 'rbw' ),			    % resolution BW
    if nargin<2,
	gpib( 'wrt', ud, 'RB?' );
	x = str2num( gpib( 'rd', ud ) );
    else
	gpib( 'wrt', ud, ['RB' sprintf('%.0f',data) 'HZ'] );
    end


elseif strcmp( op, 'atten' ),			    % input attenuator
    if nargin<2,
	gpib( 'wrt', ud, 'AT?' );
	x = str2num( gpib( 'rd', ud ) );
    else
	gpib( 'wrt', ud, ['AT' sprintf('%.0f',data) 'DB'] );
    end


elseif strcmp( op, 'trace' ),			    % read trace A
    gpib( 'wrt', ud, 'SNGLS' );			    % Single sweep
    gpib( 'wrt', ud, 'TS;DONE?' );		    % Take Sweep
    gpib( 'rd', ud );				    % read the result of DONE?
    gpib( 'wrt', ud, 'TDF P;TRA?' );
    y = str2num(['[' gpib( 'rd', ud ) ']'])';
    gpib( 'wrt', ud, 'FA?;FB?' );
    x = linspace( str2num( gpib('rd',ud) ), str2num( gpib('rd',ud) ), length(y) )';


elseif strcmp( op, 'sweep' ),			    % sweep time
    if nargin<2,
	gpib( 'wrt', ud, 'ST?' );
	x = str2num( gpib( 'rd', ud ) );
    else
	gpib( 'wrt', ud, ['ST' num2str(data) 'SEC'] );
    end


elseif strcmp( op, 'ref' ),
    if nargin<2,
	gpib( 'wrt', ud, 'RL?' );
	x = str2num( gpib( 'rd', ud ) );
    else
	gpib( 'wrt', ud, ['RL' num2str(data) 'DBM'] );
    end

elseif strcmp( op, '10mhz' ),
    gpib( 'wrt', ud, ['FREF' data] );


elseif strcmp( op, 'peaks' ),
    gpib( 'wrt', ud, 'SNGLS' );			    % Single sweep
    gpib( 'wrt', ud, 'TS;DONE?' );		    % Take Sweep
    gpib( 'rd', ud );				    % read the result of DONE?
    gpib( 'wrt', ud, 'MKPK HI' );		    % find highest
    gpib( 'wrt', ud, 'MKF?;MKA?' );
    x = str2num( gpib( 'rd', ud ) );
    y = str2num( gpib( 'rd', ud ) );
    if nargin<2, return; end
    for i=2:data,
 	gpib( 'wrt', ud, 'MKPK NH' );		    % find next highest peak
	gpib( 'wrt', ud, 'MKF?;MKA?' );
	x = [x; str2num( gpib( 'rd', ud ) )];
	y = [y; str2num( gpib( 'rd', ud ) )];
    end


elseif strcmp( op, 'marker' ),			    % marker freq, amp
    gpib( 'wrt', ud, 'MKF?;MKA?' );
    x = str2num( gpib( 'rd', ud ) );
    y = str2num( gpib( 'rd', ud ) );


elseif strcmp( op, 'plot' ),			    % plot trace
    [x,y] = hp8562( 'trace' );
    x = x/1e6;
    gpib( 'wrt', ud, 'RB?;VB?;FREF?;RL?;AT?;ST?' );
    figure
	plot( x, y )
	axis([x(1) x(601) -100 0])
	title('HP8562')
	xlabel('Freq (MHz)'); ylabel('Power (dBm)' )
	grid
	text( .05, .95, ['RBW = ',      gpib( 'rd', ud )], 'units', 'norm' )
	text( .05, .90, ['VBW = ',      gpib( 'rd', ud )], 'units', 'norm' )
	text( .05, .85, ['10 Mhz = ',   gpib( 'rd', ud )], 'units', 'norm' )
	text( .05, .80, ['Ref level = ',gpib( 'rd', ud )], 'units', 'norm' )
	text( .05, .75, ['Attn = ',     gpib( 'rd', ud )], 'units', 'norm' )
	text( .05, .70, ['Sweep = ',    gpib( 'rd', ud )], 'units', 'norm' )
	text( .85,1.03,                              date, 'units', 'norm' )


elseif strcmp( op, 'close' ),
    if length( ud ) == 0, return; end
    lcl_hp8562 = [];
    err = gpib( 'onl', ud, 0 );

else
    error( 'bad op code' )

end


function hp8662( op, data )

%   function hp8662( op, data )
%
%   hp8662( 'open' )	-- opens GPIB device
%   hp8662( 'freq' )    -- tunes device to frequency 'data' (Hz)
%   hp8662( 'power' )   -- sets output power to 'data' (dBm) 
%   hp8662( 'close' )   -- closes GPIB device


global lcl_hp8662		% static 'local' variable
ud = lcl_hp8662;

dev = 'dev16';


if strcmp( op, 'open' ),
    hp8662( 'close' );
	
    ud = gpib( 'find', dev );
    if ud < 0,
	error( ['Couldn''t find ' dev] );
    end
    lcl_hp8662 = ud;
    gpib( 'clr', ud );
    
elseif strcmp( op, 'freq' ),
    gpib( 'wrt', ud, ['Fr' int2str(data) 'Hz'] );

elseif strcmp( op, 'power' ),
    if data > 0,
	gpib( 'wrt', ud, ['AP' num2str(data) '+D'] );
    else
	gpib( 'wrt', ud, ['AP' num2str(-data) '-D'] );
    end

elseif strcmp( op, 'close' ),
    if length( ud ) == 0, return; end
    lcl_hp8662 = [];
    err = gpib( 'onl', ud, 0 );

else
    error( 'bad op code' )

end



function str=tcpip_readln(varargin)
  
% str=tcpip_readln(fid,len)
% str=tcpip_readln(len)
%
% fid   is file id.
% len   is maximum length to be read.
%
% Reads a line of charters terminated by newline character (LF).
% If the a full line (until LF) isn available at the
% moment a empty string will be returned.
% CR and LF characters will not be returned in the string.
%
% If only one argument is given then fid is set to current. (value: -2)
% default file id value is current file. (last used tcpip connection)
  fid=-2;
  
  if nargin>1,
    fid=varargin{1};
    len=varargin{2};
  else
    len=varargin{1};
  end
  
  strin=tcpipmex(4,fid,len);
  
  str=char([]);
  if length(strin)>0,
    for n=1:length(strin),
      if strin(n)~=13 & strin(n)~=10,
        str(end+1)=strin(n);
      end
    end
  end
  return;
  
  
  
  
  
  
  
  
  
  
  
  


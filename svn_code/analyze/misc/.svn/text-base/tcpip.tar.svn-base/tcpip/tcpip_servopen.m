function fid=tcpip_servopen(port)
% fid=tcpip_servopen(port)    Opens tcpip comunication as server.
%
% port   is portnumber to use when waiting for connection.
% fid    is returned handler to open tcpip channel. If error then fid is -1
%
% This function is usfull when you in a simple way whants to create a
% very simple tcpip server which handles only one connection.
% It creates a local socket and waits until any remote process
% connects to it and then returns a valid handler to it.
%
% Example:
%
% disp('Waiting for someone to connect to port 4444...');
% fid=tcpip_servopen(4444);
% if fid=-1,
%  error('TCP/IP Connection error!');
% end
% disp('Connection! :-)');
% disp('Now sending a message and closing!')
% tcpip_write('Hello!!',string(10)); %string(10) generates newline
% tcpip_close(fid);
%
  fid=tcpipmex(10,-1,port);


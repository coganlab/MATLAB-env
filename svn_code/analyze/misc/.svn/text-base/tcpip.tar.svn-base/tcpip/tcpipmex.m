function tcpipmex(varargin)
% tcpipmex ithe core of
%
%
  
  disp('tcpipmex mex-file is not compiled for your platform!!');
  disp('Compiling tcpipmex.c as mexfile for your platform....');
  mex tcpipmex.c
  error('tcpipmex is now compiled (!??). restart your matlab script/function.');

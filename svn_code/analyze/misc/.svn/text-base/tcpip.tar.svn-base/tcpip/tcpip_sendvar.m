function ret=tcpip_sendvar(varargin)
%
%  ret = tcpip_sendvar(ip_fid,var)
%
%  ip_fid    File id for tcpip channel.
%  var       Variable to send
%  ret       Return value.
%
% Get a file over network with tcpip.
% Using a own protocol for this system.
% se tcpip_sendfile()
  
  
  if nargin>1,
    ip_fid=varargin{1};
    argstep=2;
  else
    ip_fid=-2;        %Use current tcpip file;
    argstep=1;
  end
  
  var1=varargin{argstep};
  
  name=[tempname,'.mat'];
  save(name,'var1');
  tcpip_sendfile(ip_fid,name);
  delete(name);

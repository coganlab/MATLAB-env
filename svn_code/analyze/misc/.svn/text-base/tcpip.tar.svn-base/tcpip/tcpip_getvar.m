function var=tcpip_getvar(varargin)
%
%  ret = tcpip_getvar(ip_fid)
%
%  ip_fid    File id for tcpip channel.
%  ret       Variable to return
%
% Get a file over network with tcpip.
% Using a own protocol for this system.
% se tcpip_sendvar()
  
  if nargin==0,
    ip_fid=-2;        %Use current tcpip file;
  else
    ip_fid=varargin{1};
  end
  
  name=tempname;
  
  tcpip_getfile(ip_fid,[name,'.mat']);
  var1=[];
  load(name);
  unix(['rm "',name,'.mat"']);
  var=var1;
  return;

#define UNIX
#include "ugpib.h"		/* part of National Instruments GPIB distribution */
#define HUGE
#define ibcmda(x,y,z)	NOSUPPORT
#define ibevent(x,y)	NOSUPPORT
#define ibrda(x,y,z)	NOSUPPORT
#define ibstop(x)		NOSUPPORT
#define ibwrta(x,y,z)	NOSUPPORT

typedef int ITYPE;

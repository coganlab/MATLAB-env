function hp8672( op, data )

%	function hp8672( op, data )
%
%	hp8672( 'open' )	-- opens GPIB device
%	hp8672( 'freq' )    -- tunes device to frequency 'data' (Hz)
%	hp8672( 'power' )   -- sets output power to 'data' (dBm) 
%	hp8672( 'fs pwr' )  -- sets output power to 'data' (dBFS) 
%	hp8672( 'set fs' )  -- sets ref power for 'fs pwr' (0 dBFS) 
%	hp8672( 'FM' )      -- FM mod 400 Hz rate @ 'data' (KHz) deviation 
%	hp8672( 'close' )   -- closes GPIB device


global lcl_hp8672 lcl_hp8672_fs
ud = lcl_hp8672;
dev = 'dev19';


if strcmp( op, 'open' ),
	if length( ud ) > 0, return; end
		
	ud = gpib( 'find', dev );
	if ud < 0,
		gpib( 'error' );
		error( ['Couldn''t find ' dev] );
	end
	gpib( 'clr', ud );
	gpib( 'pad', ud, 19 );
	gpib( 'wrt', ud, 'M0N7O1' );		% AM off; FM off; ALC int norm
	lcl_hp8672 = ud;

elseif strcmp( op, 'freq' ),
	gpib( 'wrt', ud, ['P' sprintf('%08d',round(data/1000)) 'Z1'] );

elseif strcmp( op, 'power' ),
	if data > 0 | data < -99,
		error('HP8672: power out of range')
	end
	data = round( data );
	x = mod( -data, 10 );
	gpib( 'wrt', ud, ['K' int2str(floor(-data/10)) setstr(x+51) ] );

elseif strcmp( op, 'fs pwr' ),
	hp8672( 'power', lcl_hp8672_fs + data );

elseif strcmp( op, 'set fs' ),
	lcl_hp8672_fs = data;

elseif strcmp( op, 'close' ),
	if length( ud ) < 0, return; end
	lcl_hp8672 = [];
	err = gpib( 'onl', ud, 0 );

else
	error( 'bad op code' )

end


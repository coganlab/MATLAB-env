function hp8642( op, data )

%	function hp8642( op, data )
%
%	hp8642( 'open' )	-- opens GPIB device
%	hp8642( 'freq' )    -- tunes device to frequency 'data' (Hz)
%	hp8642( 'power' )   -- sets output power to 'data' (dBm) 
%	hp8642( 'fs pwr' )  -- sets output power to 'data' (dBFS) 
%	hp8642( 'set fs' )  -- sets ref power for 'fs pwr' (0 dBFS) 
%	hp8642( 'FM' )      -- FM mod 400 Hz rate @ 'data' (KHz) deviation 
%	hp8642( 'close' )   -- closes GPIB device


global lcl_hp8642 lcl_hp8642_fs
ud = lcl_hp8642;
dev = 'dev2';


if strcmp( op, 'open' ),
	if length( ud ) > 0, hp8642('close'); end
		
	ud = gpib( 'find', dev );
	if ud < 0,
		gpib( 'error' );
		error( ['Couldn''t find ' dev] );
	end
	gpib( 'clr', ud );
	lcl_hp8642 = ud;

elseif strcmp( op, 'freq' ),
	gpib( 'wrt', ud, ['Fr' int2str(data) 'Hz'] );

elseif strcmp( op, 'power' ),
	gpib( 'wrt', ud, ['AP' num2str(data) 'DM'] );

elseif strcmp( op, 'fs pwr' ),
	gpib( 'wrt', ud, ['AP' num2str(lcl_hp8642_fs+data) 'DM'] );

elseif strcmp( op, 'set fs' ),
	lcl_hp8642_fs = data;

elseif strcmp( op, 'FM' ),
	if data~=0,
		gpib( 'wrt', ud, ['FM' num2str(data) 'KZ'] );
		gpib( 'wrt', synth, 'M1' );				% 400 Hz rate
	else
		gpib( 'wrt', synth, 'M0' );				% modulation off
	end

elseif strcmp( op, 'close' ),
	if length( ud ) == 0, return; end
	lcl_hp8642 = [];
	err = gpib( 'onl', ud, 0 );

else
	error( 'bad op code' )

end


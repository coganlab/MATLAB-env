/* 
*    gpib.c -- source for Matlab MEX file.
*		    Tom L. Davis
*		    last modified 6-18-98
*
*     MATLAB call
*           [value, ibsta] = gpib( routine_name [, optional_arguments ... ] )
*
*     Version: 2.0
*/


#define V4_COMPAT
#define STRLEN	4096
#define NOSUPPORT	ERR; mexErrMsgTxt("Unsupported GPIB function")

#include <string.h>
#include <stdlib.h>
#include "mex.h"
#include "gpib.h"


enum {
    ASK_,
    BNA_,
    CAC_,
    CLR_,
    CMD_,
    CMDA_,
    CONFIG_,
    DEV_,
    DMA_,
    EOS_,
    EOT_,
    ERR_,
    EVENT_,
    FIND_,
    GTS_,
    IST_,
    LINES_,
    LLO_,
    LN_,
    LOC_,
    ONL_,
    PAD_,
    PCT_,
    PPC_,
    RD_,
    RDA_,
    RDB_,
    RDF_,
    RDI_,
    RPP_,
    RSC_,
    RSP_,
    RSV_,
    SAD_,
    SGNL_,
    SIC_,
    SRE_,
    STOP_,
    TMO_,
    TRACE_,
    TRG_,
    WAIT_,
    WRT_,
    WRTA_,
    WRTF_,
    NFUNC
};




int  gpiberr( char* name );
int  getString( Matrix *ptr, char *str );



/* trace bit: 0=>no trace, 1=>trace, 2=>trace+print input args   */

static int trace;


typedef struct info {
    char    name[8];
    int	    index;
    int	    nargout;
    int	    nargin;
} func_info;

static func_info func[] = {
    {	"ask",	    ASK_,   2,	2   },
    {	"bna",	    BNA_,   1,	2   },
    {	"cac",	    CAC_,   1,	2   },
    {	"clr",	    CLR_,   1,	1   },
    {	"cmd",	    CMD_,   1,	2   },
    {	"cmda",	    CMDA_,  1,	2   },
    {	"config",   CONFIG_,1,	3   },
    {	"dev",	    DEV_,   1,	6   },
    {	"dma",	    DMA_,   1,	2   },
    {	"eos",	    EOS_,   1,	2   },
    {	"eot",	    EOT_,   1,	2   },
    {	"err",      ERR_,   1,	0   },
    {	"event",    EVENT_, 2,	1   },
    {	"find",	    FIND_,  1,	1   },
    {	"gts",	    GTS_,   1,	2   },
    {	"ist",	    IST_,   1,	2   },
    {	"lines",    LINES_, 2,	1   },
    {	"llo",	    LLO_,   1,	1   },
    {	"ln",	    LN_,    2,	3   },
    {	"loc",	    LOC_,   1,	1   },
    {	"onl",	    ONL_,   1,	2   },
    {	"pad",	    PAD_,   1,	2   },
    {	"pct",	    PCT_,   1,	1   },
    {	"ppc",	    PPC_,   1,	2   },
    {	"rd",	    RD_,    2,	1   },
    {	"rda",	    RDA_,   2,	1   },
    {	"rdb",      RDB_,   2,  2   },
    {	"rdf",	    RDF_,   1,	2   },
    {	"rdi",      RDI_,   2,  2   },
    {	"rpp",	    RPP_,   2,	1   },
    {	"rsc",	    RSC_,   1,	2   },
    {	"rsp",	    RSP_,   2,	1   },
    {	"rsv",	    RSV_,   1,	2   },
    {	"sad",	    SAD_,   1,	2   },
    {	"sgnl",	    SGNL_,  1,	2   },
    {	"sic",	    SIC_,   1,	2   },
    {	"sre",	    SRE_,   1,	2   },
    {	"stop",	    STOP_,  1,	1   },
    {	"tmo",	    TMO_,   1,	2   },
    {	"trace",    TRACE_, 1,	1   },
    {	"trg",	    TRG_,   1,	1   },
    {	"wait",	    WAIT_,  1,	2   },
    {	"wrt",	    WRT_,   1,	2   },
    {	"wrta",	    WRTA_,  1,	2   },
    {	"wrtf",	    WRTF_,  1,	2   }
};


void mexFunction(
    int	    nlhs,
    Matrix  *plhs[],
    int	    nrhs,
    Matrix  *prhs[]
) 
{
    unsigned long  in[7], iu;
    long			i;
    ITYPE			int_ret=0;			/* NI-488M routine return	*/
    int				len;
    short			short_val=0;		/* used by iblines, ibln	*/
    ITYPE			int_val;			/* used by ibask		*/
    char			char_val;			/* used by ibrpp, rsp		*/
    char			string[STRLEN+1];
    char			name[8];
    char			*byte_ptr;
    short			*short_ptr;
    double			*data_ptr;
    double HUGE 	*data_hptr;
    func_info		*func_ptr;


    /* Read function name */

    if( nrhs < 1 ){
        mexErrMsgTxt("GPIB requires at least one input argument.");
    }
    if( mxGetString( prhs[0], name, 8 ) ) {
        mexErrMsgTxt("GPIB bad first argument.");
    }


    /* find the function */

    func_ptr = (func_info *) bsearch( name, func, NFUNC, sizeof(func_info), 
		(int (*)(const void *, const void *)) strcmp );

    if( func_ptr == NULL ) {
		mexErrMsgTxt("GPIB function name doesn't exist or isn't supported.");
    }


    /* Check for correct number of arguments*/

    if( nrhs != func_ptr->nargin + 1 ){
		mexErrMsgTxt("GPIB wrong number of input arguments.");
    }
    if( nlhs > func_ptr->nargout ){
		mexErrMsgTxt("GPIB too many output arguments.");
    }


    /* Read all input arguments as scaler intergers */

    for( i=1; i<nrhs; i++ ) {
		if( mxGetN(prhs[i]) == 0 ){
			mexErrMsgTxt("GPIB input argument empty matrix.");
		}
		in[i] = (unsigned long) mxGetScalar(prhs[i]);
		if( trace > 1 ) {			/* print input arguments */
			if( mxIsString( prhs[i] ) ) {
				getString( prhs[i], string );
	    		mexPrintf( "%8s: arg%d  = '%s'\n", name, i, string );
			} else {
	    		mexPrintf( "%8s: arg%d  = %d\n", name, i, in[i] );
			}
		}

    }


    switch( func_ptr->index ) {


    case ASK_:
		int_ret = ibask( in[1], in[2], &int_val ); 
		plhs[0] = mxCreateFull( 1, 1, REAL );
    	data_ptr = mxGetPr(  plhs[0] );
    	*data_ptr = (double) int_val;
		break;
		
    case BNA_:
		getString( prhs[2], string );
		int_ret = ibbna( in[1], string );
		break;

    case CAC_:
		int_ret = ibcac( in[1], in[2] );
		break;
	
    case CLR_:
		int_ret = ibclr( in[1] );
		break;
	
    case CMD_:
		len = getString( prhs[2], string );
		int_ret = ibcmd( in[1], string, (long) len );
		break;
	
    case CMDA_:   			/* Added by ML 12-18-96 */
		len = getString( prhs[2], string );
		int_ret = ibcmda( in[1], string, (long) len );
		break;

    case CONFIG_:
		int_ret = ibconfig( in[1], in[2], in[3] );
		break;
	
    case DEV_:
		int_ret = ibdev( in[1], in[2], in[3], in[4], in[5], in[6] );
		break;
	
    case DMA_:
		int_ret = ibdma( in[1], in[2] );
		break;
	
    case EOS_:
		int_ret = ibeos( in[1], in[2] );
		break;
	
    case EOT_:
		int_ret = ibeot( in[1], in[2] );
		break;
	
    case EVENT_:      				/* Added by ML 12-18-96 */
		int_ret = ibevent( in[1], &short_val );
		plhs[0] = mxCreateFull( 1, 1, REAL );
		data_ptr = mxGetPr(  plhs[0] );
		*data_ptr = (double) short_val;
		break;

    case FIND_:
		getString( prhs[1], string );
		int_ret = ibfind( string );
		break;
	
    case GTS_:
		int_ret = ibgts( in[1], in[2] );
		break;
	
    case IST_:
		int_ret = ibist( in[1], in[2] );
		break;
	
    case LINES_:
#ifdef MAC
		int_ret = iblines( in[1], (unsigned short *) &short_val );
#else	
		int_ret = iblines( in[1], &short_val );
#endif
        plhs[0] = mxCreateFull( 1, 1, REAL );
    	data_ptr = mxGetPr(  plhs[0] );
    	*data_ptr = (double) short_val;
		break;
	
    case LN_:
		int_ret = ibln( in[1], in[2], in[3], &short_val );
        plhs[0] = mxCreateFull( 1, 1, REAL );
    	data_ptr = mxGetPr(  plhs[0] );
    	*data_ptr = (double) short_val;
		break;
	
    case LOC_:
		int_ret = ibloc( in[1] );
		break;
	
    case LLO_:
		int_ret = ibllo( in[1] );
		break;
	
    case ONL_:
		int_ret = ibonl( in[1], in[2] );
		break;
	
    case PAD_:
		int_ret = ibpad( in[1], in[2] );
		break;
	
    case PCT_:
		int_ret = ibpct( in[1] );
		break;
	
    case PPC_:
		int_ret = ibppc( in[1], in[2] );
		break;
	
    case RD_:
		int_ret = ibrd( in[1], string, (long) STRLEN );
		string[ibcnt] = '\0';
		plhs[0] = mxCreateString( string );
		break;
		
   case RDA_:    					/* Added by ML 12-18-96 */
		int_ret = ibrda( in[1], string, (long) STRLEN );
		string[ibcnt-1] = '\0';
		plhs[0] = mxCreateString( string );
		break;

    case RDB_:						/* Added by DS  4-25-97 */
		byte_ptr = (char *) mxCalloc( in[2], sizeof(char) );
		int_ret = ibrd( in[1], byte_ptr, in[2] );
		plhs[0] = mxCreateFull( in[2], 1, REAL );
		data_hptr = mxGetPr( plhs[0] );
		for( i=0; i<ibcnt; i++ ) {
			data_hptr[i] = (double) byte_ptr[i];
		}
		mxSetM( plhs[0], ibcnt );
		mxFree( byte_ptr );
		break;

    case RDI_:						/* Added by DS  4-25-97 */
		short_ptr = (short *) mxCalloc( in[2], sizeof(short) );
		int_ret = ibrd( in[1], (char*) short_ptr, in[2]*sizeof(short) );
		plhs[0] = mxCreateFull( in[2], 1, REAL );
		data_hptr = mxGetPr( plhs[0] );
		for( iu=0; iu<(ibcnt+1)/sizeof(short); iu++ ) {
			data_hptr[iu] = (double) short_ptr[iu];
		}
		mxSetM( plhs[0], (ibcnt+1)/sizeof(short) );
		mxFree( short_ptr );
		break;
   
    case RDF_:
		getString( prhs[2], string );
		int_ret = ibrdf( in[1], string );
		break;
	
    case RPP_:
		int_ret = ibrpp( in[1], &char_val );
        plhs[0] = mxCreateFull( 1, 1, REAL );
    	data_ptr = mxGetPr( plhs[0] );
    	*data_ptr = (double) char_val;
		break;
	
    case RSC_:
		int_ret = ibrsc( in[1], in[2] );
		break;
	
    case RSP_:
		int_ret = ibrsp( in[1], &char_val );
        plhs[0] = mxCreateFull( 1, 1, REAL );
    	data_ptr = mxGetPr( plhs[0] );
    	*data_ptr = (double) char_val;
		break;
	
    case RSV_:
		int_ret = ibrsv( in[1], in[2] );
		break;
	
    case SAD_:
		int_ret = ibsad( in[1], in[2] );
		break;
	
    case SGNL_:
		int_ret = ibsgnl( in[1], in[2] );
		break;

    case SIC_:
#ifdef UNIX
		int_ret = ibsic( in[1], in[2] );
#else	
		if( nrhs != 2 ){
			mexErrMsgTxt("GPIB wrong number of input arguments.");
		}
		int_ret = ibsic( in[1] );
#endif
		break;

    case SRE_:
		int_ret = ibsre( in[1], in[2] );
		break;
	
    case STOP_:    			/* Added by ML 12-18-96 */
		int_ret = ibstop( in[1]);
		break;
	
    case TMO_:
		int_ret = ibtmo( in[1], in[2] );
		break;
	
    case TRG_:
		int_ret = ibtrg( in[1] );
		break;
	
    case WAIT_:
		int_ret = ibwait( in[1], in[2] );
		break;
	
    case WRT_:
		len = getString( prhs[2], string );
		int_ret = ibwrt( in[1], string, (long) len );
		break;
	
    case WRTA_:     			/* Added by ML 12-18-96 */
		len = getString( prhs[2], string );
		int_ret = ibwrta( in[1], string, (long) len );
		break;

    case WRTF_:
		getString( prhs[2], string );
		int_ret = ibwrtf( in[1], string );
		break;
	
    case ERR_:
		int_ret = iberr;
		ibsta = CMPL;
		break;
	
    case TRACE_:
		trace = in[1];
		ibsta = CMPL;
		int_ret = ibsta;
	break;
	
    default:
		mexErrMsgTxt("GPIB should never get here.");
	
    }


    if( nlhs == func_ptr->nargout ){		/* caller does error handling */
        plhs[nlhs-1] = mxCreateFull( 1, 1, REAL );
    	data_ptr = mxGetPr(  plhs[nlhs-1] );
    	*data_ptr = (double) int_ret;
	if( trace ) {
	    gpiberr( name );
	};

    }else if( ibsta & ERR ) {				/* Check status return	*/
		gpiberr( name );
		mexErrMsgTxt( "GPIB call failed" );

    }else if( trace ) {						/* print ibsta */
		gpiberr( name );

    };


}



/* This routine prints error messages */

int gpiberr( char *name ) {

    mexPrintf( "%8s: ibsta = 0x%04x <", name, ibsta );
    if( ibsta & ERR  ) mexPrintf( " ERR"  );
    if( ibsta & TIMO ) mexPrintf( " TIMO" );
    if( ibsta & END  ) mexPrintf( " END"  );
    if( ibsta & SRQI ) mexPrintf( " SRQI" );
    if( ibsta & RQS  ) mexPrintf( " RQS"  );
    if( ibsta & CMPL ) mexPrintf( " CMPL" );
    if( ibsta & LOK  ) mexPrintf( " LOK"  );
    if( ibsta & REM  ) mexPrintf( " REM"  );
    if( ibsta & CIC  ) mexPrintf( " CIC"  );
    if( ibsta & ATN  ) mexPrintf( " ATN"  );
    if( ibsta & TACS ) mexPrintf( " TACS" );
    if( ibsta & LACS ) mexPrintf( " LACS" );
    if( ibsta & DTAS ) mexPrintf( " DTAS" );
    if( ibsta & DCAS ) mexPrintf( " DCAS" );
    mexPrintf( " >\n" );

    if( ibsta & ERR  ) {
		mexPrintf( "%8s  iberr = %d", "", iberr );
		if( iberr == EDVR ) mexPrintf( "       EDVR <Error>\n" );
		if( iberr == ECIC ) mexPrintf( "       ECIC <Not CIC>\n" );
		if( iberr == ENOL ) mexPrintf( "       ENOL <No listener>\n" );
		if( iberr == EADR ) mexPrintf( "       EADR <Address error>\n" );
		if( iberr == EARG ) mexPrintf( "       EARG <Invalid argument>\n" );
		if( iberr == ESAC ) mexPrintf( "       ESAC <Not system controller>\n" );
		if( iberr == EABO ) mexPrintf( "       EABO <Operation aborted>\n" );
		if( iberr == ENEB ) mexPrintf( "       ENEB <No GPIB board>\n" );
		if( iberr == ECAP ) mexPrintf( "       ECAP <No capability>\n" );
		if( iberr == EFSO ) mexPrintf( "       EFSO <File system error>\n" );
		if( iberr == EBUS ) mexPrintf( "       EBUS <Command error>\n" );
		if( iberr == ESTB ) mexPrintf( "       ESTB <Status byte lost>\n" );
		if( iberr == ESRQ ) mexPrintf( "       ESRQ <SRQ stuck on>\n" );
		if( iberr == ETAB ) mexPrintf( "       ETAB <Table overflow>\n" );
	}
    mexPrintf( "%8s  ibcnt = %d\n", "", ibcnt );

    return iberr;
}




/* gets Matlab string matrix into character array */

int getString( Matrix *ptr, char *str )
{
    int len = mxGetN( ptr );
	
    if( !mxIsString( ptr ) ) {
		mexErrMsgTxt("GPIB argument must be a string");
    }
	
    if( len >= STRLEN ) {
		mexErrMsgTxt("GPIB string too long.");
    }

    if( mxGetString( ptr, str, len+1 ) ) {
  		mexErrMsgTxt("GPIB bad string argument.");
    }
    return len;
}







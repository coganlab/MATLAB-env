#define WIN16
#include "windecl.h"		/* part of National Instruments GPIB distribution */
#define HUGE			__huge
#define ibllo(x)		NOSUPPORT
#define ibsgnl(x,y)		NOSUPPORT

typedef short ITYPE;
